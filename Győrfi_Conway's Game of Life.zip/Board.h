#pragma once

// Deallocates data, and next_data
void FreeBoard();

// Creates, initializes data and next_data (with dead cells / 0-s) to store the new board
// Automatically deallocates the previous memory (if needed)
// Draws the borders of the board, with a given offset, to leave space for instructions
void NewBoard(size_t M, size_t N);

// Advance the simulation
void UpdateBoard();

// Returns the specified element of the board, using 2D array indices
char Get(size_t row, size_t column);

// Sets the specified element to the give value, using 2D array indices
void Set(size_t row, size_t column, char value);

void TestSet(size_t row, size_t column, char value);

// Returns the height of the board
size_t Get_M();

// Returns the width of the board
size_t Get_N();

// Returns the generation number
int GetGeneration();

// Returns the population
int GetPopulation();