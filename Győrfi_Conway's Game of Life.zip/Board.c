#include <stdio.h>
#include <stdlib.h>
#include "Board.h"
#include <assert.h>

// Creates a static instance of the Board struct
static struct Board
{
	size_t M; // # of logical rows
	size_t N; // # of logical columns
	int generation;
	char* data;
	char* next_data;
} board;

void FreeBoard()
{
	free(board.data);
	free(board.next_data);
}

void NewBoard(size_t M, size_t N)
{
	FreeBoard();
	board.M = M;
	board.N = N;
	board.generation = 0;

	board.data = (char*)malloc((M+2) * (N+2) * sizeof(char));
	assert(board.data);
	board.next_data = (char*)malloc((M+2) * (N+2) * sizeof(char));
	assert(board.data);

	// Initialize the board with 0-s
	const int trueSize = (M + 2) * (N + 2);
	for (int i = 0; i < trueSize; i++)
	{
		board.next_data[i] = board.data[i] = 0;
	}

	// Draw borders (only needed when we initialize a new board)
	for (int j = 0; j < N + 2; j++)
		printf("#");
	printf("\n");
	for (int i = 0; i < M; i++)
	{
		printf("#");
		for (int j = 0; j < N; j++)
			printf(" ");
		printf("#\n");
	}
	for (int j = 0; j < N + 2; j++)
		printf("#");
}

void UpdateBoard()
{
	board.generation++;
	for (int i = 0; i < board.M; i++) // row
	{
		for (int j = 0; j < board.N; j++) // column
		{
			char currentCell = Get(i, j);
			int neighbourSum = -currentCell; // this way the current element cancels out, since we add it in the 3x3 loop
			for (int k = i-1; k <= i + 1; k++) // row of current 3x3 adjacent grid
			{
				for (int l = j-1; l <= j + 1; l++) // column of current 3x3 adjacent grid
				{
					neighbourSum += Get(k, l);
				}
			}
			if (currentCell == 0) // if cell is dead
			{
				if (neighbourSum == 3)
				{
					Set(i, j, 1); // becomes live by reproduction
				}
				else
				{
					Set(i, j, 0); // remains dead
				}
			}
			else
			{
				if (neighbourSum > 3 || neighbourSum < 2)
				{
					Set(i, j, 0); // dies by under-, overpopulation
				}
				else
				{
					Set(i, j, 1); // remains live
				}
			}
		}
	}
	// swap the pointers, so data points to what next_data pointed to
	char* temp = board.data;
	board.data = board.next_data;
	board.next_data = temp;
}

// Returns the character at [row][column] of the board without the padding row and column
char Get(size_t row, size_t column)
{
	assert(board.data);
	return board.data[(row+1) * (board.N+2) + column+1];
}

// Sets the character at [row][column] of the board without the padding row and column
void Set(size_t row, size_t column, char value)
{
	assert(board.next_data);
	board.next_data[(row+1) * (board.N+2) + column+1] = value;
}

// Used for testing purposes
void TestSet(size_t row, size_t column, char value)
{
	assert(board.data);
	board.data[(row + 1) * (board.N + 2) + column + 1] = value;
}

size_t Get_M()
{
	return board.M;
}

size_t Get_N()
{
	return board.N;
}

int GetGeneration()
{
	return board.generation;
}

int GetPopulation()
{
	int population = 0;
	for (int i = 0; i < board.M; i++)
	{
		for (int j = 0; j < board.N; j++)
		{
			population += Get(i, j);
		}
	}
	return population;
}
